﻿using System;
namespace EX9._110
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите слово => ");
            string mass = Console.ReadLine();
            int count = 0;
            int count1 = proverkaL(mass);
            for (int i = 0; i < mass.Length; i++)
            {
                if (count == 0)
                {
                    if (mass[i].ToString().ToLower() == "о")
                    {
                        count++;
                        continue;
                    }
                }
                if (mass[i].ToString().ToLower() == "л")
                {
                    if (count1 == 1)
                        continue;
                    else
                        count1--;
                }
                Console.Write(mass[i]);
            }            
            Console.ReadKey();
        }
        static int proverkaL(string slovo)
        {
            int count = 0;
            for (int i = 0; i < slovo.Length; i++)
            {
                if (slovo[i].ToString().ToLower() == "л")
                    count++;
            }
            return count;
        }
    }
}
