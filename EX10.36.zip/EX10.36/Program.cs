﻿using System;
namespace EX10._36
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите число символов => ");
            int a = int.Parse(Console.ReadLine());
            for (int i = 0; i < a; i++)
                Console.WriteLine("*");
            Console.ReadKey();
        }
    }
}
