﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EX9._143
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите число или слово => ");
            string s = Console.ReadLine();
            if (s[0] != '0')
            {
                for (int i = 0; i < s.Length; i++)
                {
                    bool error = false;
                    if (!Char.IsDigit(s[i]))
                    {
                        error = true;
                        break;
                    }
                    if (!error)
                    {
                        Console.Clear();
                        Console.WriteLine("Это число");
                    }
                }
            }
            Console.ReadLine();
        }
    }
}
